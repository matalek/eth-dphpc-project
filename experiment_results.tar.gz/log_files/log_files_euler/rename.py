#!/usr/bin/env python
import subprocess
import csv

ls = subprocess.check_output('ls euler_circle', shell=True)[:-1]

for file in ls.split('\n'):
    subprocess.call('mv euler_circle/' + file + ' euler_circle/euler_circle_' + file.replace('log_results_', '').replace('_t_', '_') , shell=True)
